#include <iostream>

#include "directory_checker.h"
#include "file_writer.h"

namespace fs = std::filesystem;

void WriteToFile(FileWriter& file_writer, const std::vector<File>& files) {
  file_writer.Write(files);
}

int main(int argc, char* argv[argc + 1]) {
  if (argc != 2) {
    std::cerr
        << "Program should have 1 argument - path to the directory.\n"
        << "Example: " << argv[0] << " /Users/user/Documents"
        << std::endl;
    return EXIT_FAILURE;
  }

  try {
    DirectoryChecker dir_check(argv[1]);
    auto files = dir_check.GetFiles();

    TxtFileWriter txt_file_writer("result.txt");
    CsvFileWriter csv_file_writer("result.csv");
    JsonFileWriter json_file_writer("result.json");

    WriteToFile(txt_file_writer, files);
    WriteToFile(csv_file_writer, files);
    WriteToFile(json_file_writer, files);
  }
  catch (const std::exception& exception) {
    std::cerr << exception.what() << std::endl;
    return EXIT_FAILURE;
  }
  catch (...) {
    std::cerr << "Unknown error" << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}
